

# NOT IN USE AS OF 4-1-22.  USING GENERIC_PRINT.general_test_results_dump in GMLRRun

def gmlr_generic_test_results_dump(wb, standard_config, tc_method, DATA, DATA_HEADER, ROWID_VECTOR, TARGET_VECTOR,
            OUTPUT_VECTOR):
    pass





