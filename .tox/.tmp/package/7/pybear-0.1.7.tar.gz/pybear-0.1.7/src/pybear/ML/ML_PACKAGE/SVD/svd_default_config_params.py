

def svd_default_config_params():

    svd_max_columns = float('inf')
    SVD_OUTPUT_VECTOR = []

    return svd_max_columns, SVD_OUTPUT_VECTOR







