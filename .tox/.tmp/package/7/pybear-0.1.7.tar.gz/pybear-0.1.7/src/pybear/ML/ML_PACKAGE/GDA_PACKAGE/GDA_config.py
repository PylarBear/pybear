from read_write_file import read_file_config_run as rfcr

def GDA_config():

    TARGET = rfcr.read_file_config_run('Z', '')

    DATA = rfcr.read_file_config_run('Z','')








