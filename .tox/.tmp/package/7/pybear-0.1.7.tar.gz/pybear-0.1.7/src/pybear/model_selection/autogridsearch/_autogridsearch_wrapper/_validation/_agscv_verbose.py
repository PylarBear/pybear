# Author:
#         Bill Sousa
#
# License: BSD 3 clause
#

def _agscv_verbose(_agscv_verbose: bool) -> bool:
    """
    Validate _agscv_verbose --- force to boolean.

    """

    return bool(_agscv_verbose)






