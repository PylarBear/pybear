# Author:
#         Bill Sousa
#
# License: BSD 3 clause
#


def _total_passes_is_hard(_total_passes_is_hard: bool) -> bool:
    """
    Validate _total_passes_is_hard --- force to boolean.

    """

    return bool(_total_passes_is_hard)





