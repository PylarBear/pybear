

def print_object_create_success(standard_config, object):
    print(f'\n{standard_config.upper()} {object} executed successfully.')



