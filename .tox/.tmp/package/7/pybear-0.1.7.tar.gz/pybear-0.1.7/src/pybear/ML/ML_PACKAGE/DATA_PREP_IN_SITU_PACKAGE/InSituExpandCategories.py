from ML_PACKAGE.DATA_PREP_PRE_RUN_PACKAGE import PreRunExpandCategories as prec


class InSituExpandCategories(prec.PrerunExpandCategories):
    pass













if __name__ == '__main__':

    pass












