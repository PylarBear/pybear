# Author:
#         Bill Sousa
#
# License: BSD 3 clause
#




"""

get_metadata_routing is not implemented in GSTCV(Dask).

"""





