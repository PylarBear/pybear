

def svm_output_calc(ORIGINAL_DATA, TARGET, ):










