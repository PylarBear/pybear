# Author:
#         Bill Sousa
#
# License: BSD 3 clause
#


from ._version import __version__
from ._version import __version_tuple__

__all__ = ["__version__"]







