

class SVMCoreChunkCode:
    def __init__(self):
        print(f'\n*** CHUNK OPTIMIZATION NOT AVAILABLE YET :( ***\n')






