

def mlr_default_config_params():

    MLR_OUTPUT_VECTOR = []
    mlr_batch_method = 'B'
    mlr_batch_size = int(1e12)
    mlr_rglztn_type = 'RIDGE'
    mlr_rglztn_fctr = 0

    return MLR_OUTPUT_VECTOR, mlr_batch_method, mlr_batch_size, mlr_rglztn_type, mlr_rglztn_fctr




