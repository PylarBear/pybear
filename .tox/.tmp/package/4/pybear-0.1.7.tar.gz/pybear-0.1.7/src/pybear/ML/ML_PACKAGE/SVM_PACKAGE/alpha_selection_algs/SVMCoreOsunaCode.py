

class SVMCoreOsunaCode:
    def __init__(self):
        print(f'\n*** OSUNA OPTIMIZATION NOT AVAILABLE YET :( ***\n')



























