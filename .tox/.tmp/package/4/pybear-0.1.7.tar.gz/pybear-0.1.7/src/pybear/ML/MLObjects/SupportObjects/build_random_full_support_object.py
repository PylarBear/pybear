import numpy as np












if __name__ == '__main__':

    # TEST MODULE


    DUM = build_random_full_support_object(5)

    print(DUM)




















