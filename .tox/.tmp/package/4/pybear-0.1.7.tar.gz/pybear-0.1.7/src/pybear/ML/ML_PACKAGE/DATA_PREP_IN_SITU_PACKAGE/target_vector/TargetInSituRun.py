from ML_PACKAGE.DATA_PREP_PRE_RUN_PACKAGE.target_vector import TargetPrerunRun as tpr


# CALLED by TargetInSituConfigRun
class TargetInSituRun(tpr.TargetPrerunRun):
        pass
        # INHERITS
        # __init__()
        # return_fxn()  (FOR NOW)
        # run()

        # OVERWRITES NOTHING




