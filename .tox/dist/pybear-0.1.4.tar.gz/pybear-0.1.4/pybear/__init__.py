# Author:
#         Bill Sousa
#
# License: BSD 3 clause
#

# pizza remember that this is hashed to see if modules are in dir(pybear)
# without this statement. if a-ok, then just delete.
# from . import (
#     data_validation,
#     debug,
#     model_selection,
#     new_numpy,
#     preprocessing,
#     utilities,
#     base
# )


from ._version import __version__

__all__ = ["__version__"]







