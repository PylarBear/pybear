
#CALLED BY read_write_file.filetype_package_pair_configs.filetype_package_pair_config
def excel_openpyxl_config():
    pass
    return excel_openpyxl_stuff


