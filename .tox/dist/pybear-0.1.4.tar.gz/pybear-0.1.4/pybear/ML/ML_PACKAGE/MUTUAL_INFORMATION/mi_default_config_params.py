

def mi_default_config_params():

    MI_OUTPUT_VECTOR = []
    mi_batch_method = 'B'
    mi_batch_size = int(1e12)
    mi_max_columns = float('inf')
    mi_int_or_bin_only = False
    mi_bypass_agg = False

    return MI_OUTPUT_VECTOR, mi_batch_method, mi_batch_size, mi_int_or_bin_only, mi_max_columns, mi_bypass_agg








