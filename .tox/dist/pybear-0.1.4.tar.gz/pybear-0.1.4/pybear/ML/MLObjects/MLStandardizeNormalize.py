from general_data_ops import StandardizeNormalize as sn



class MLStandardizeNormalize(sn.StandardizeNormalize):
    pass

    # BEAR THINKS THAT IF AN INT COLUMN IS STANDARDIZED / NORMALIZED THEN MOD_DTYPE MAYBE SHOULD BECOME FLOAT



















if __name__ == '__main__':

    pass
    #TestClass = MLStandardizeNormalize(DATA_OBJECT, DATA_SUPOBJ, data_given_orientation, bypass_validation=None)



