# Author:
#         Bill Sousa
#
# License: BSD 3 clause
#



import pytest

from pybear.feature_extraction.text._TextCleaner._normalize import _normalize



class TestNormalize:

    def test_pizza(self):
        pass


        # out = _normalize()












